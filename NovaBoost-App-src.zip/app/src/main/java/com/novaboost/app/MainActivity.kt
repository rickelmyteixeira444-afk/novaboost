package com.novaboost.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
	private lateinit var web: WebView

	@SuppressLint("SetJavaScriptEnabled")
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		web = WebView(this)
		web.settings.javaScriptEnabled = true
		web.setBackgroundColor(0xFF0F1115.toInt())
		web.addJavascriptInterface(Bridge(web), "ksu")
		setContentView(web)
		web.loadUrl("file:///android_asset/index.html")
	}

	override fun onBackPressed() {
		if (web.canGoBack()) web.goBack() else super.onBackPressed()
	}

	// Same exec(cmd, opts, callbackName) contract as the KernelSU WebUI, so one page serves both.
	class Bridge(private val web: WebView) {
		@JavascriptInterface
		fun exec(cmd: String, opts: String, cb: String) {
			Thread {
				var out = ""
				var err = ""
				var code = -1
				try {
					val proc = ProcessBuilder("su", "-c", cmd).start()
					out = proc.inputStream.bufferedReader().readText()
					err = proc.errorStream.bufferedReader().readText()
					code = proc.waitFor()
				} catch (e: Exception) {
					err = e.message ?: ""
				}
				val js = "window['$cb']($code,${JSONObject.quote(out)},${JSONObject.quote(err)})"
				web.post { web.evaluateJavascript(js, null) }
			}.start()
		}
	}
}
